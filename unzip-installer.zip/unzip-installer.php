<?php
/*
    * ESS Zip Installer v0.9.0
    * Author: Elite Star Services
    * Web: https://elite-star-services.com
    * 
     * @License:
	 * GPL v3 | https://elite-star-services.com/license/
    */
?>

<head>
    <!-- 3rd Party Hosted -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fontawesome-4.7@4.7.0/css/font-awesome.min.css">
    <!-- Elite Star Hosted -->
    <link rel="stylesheet" href="https://cs.elite-star-services.com/common/css/ess.css" />
    <link rel="stylesheet" href="https://cs.elite-star-services.com/common/css/servinfo.css" />
    <script src="https://cs.elite-star-services.com/common/js/jquery.min.js"></script>
    <script src="https://cs.elite-star-services.com/common/js/bootstrap.min.js"></script>
    <link rel="shortcut icon" href="https://cs.elite-star-services.com/common/img/sifavicn.png">
    <title>ServInfo - ClientZip File Extrator</title>
</head>

<!-- TITLE TABLE -->
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default panel-navbar">
                <div class='panel-heading center'><a class='si-page-title' href='https://elite-star-services.com'>Elite Star Services</a></div>
                <table class='table table-condensed'>
                    <tr class='i center bold-text'>
                        <td colspan='2'>-- ZIP EXTRACTOR --</td>
                        <td style='display:none;'></td>
                    </tr>
                </table>



                <?php
                // SET ERROR REPORTING
                error_reporting(0); //off
                //error_reporting(E_ALL); //on
                //ini_set('display_errors', '1'); //on



                echo '<div class="panel-body">';


                // IF NO FORM DATA
                if (!isset($_GET['submit'])) {



                    // PRE INSTALL CHECKS
                    echo "<table class='table' width='934px' align='center'>";
                    echo '<thead><tr><th style="display:none;"></th><th style="display:none;"></th></tr></thead>';
                    echo "<tr class='si-heading'><td colspan='2'>PRE INSTALLATION CHECKS</td><td style='display:none;'></td></tr>";



                    /*
// GET SERVER INFO / VERIFY LINUX
$vm = "";
$mach = 'hostnamectl status';
exec($mach, $macout);
foreach ($macout as $key => $value) { 
    $minf = explode(": ", $value);
    $minf[0] = trim($minf[0]);
// Get Individual Items Here 
    if ($minf[0] == "Machine ID") { $sid = $minf[1]; }
    if ($minf[0] == "Chassis") { $vm = trim($minf[1]); }
//    if ($minf[0] == "Static hostname") { $host = $minf[1]; }
//    if ($minf[0] == "Virtualization") { $vm = strtoupper($minf[1]); }
//    if ($minf[0] == "Kernel") { $ker = $minf[1]; }
}

// Backup Method to Get SID
if (!$sid) { $sid = trim(shell_exec('cat /etc/machine-id 2>/dev/null')); }


// WARN AND DIE IF NO SID
echo '<tr><td class="e">Linux Based Server</td>';
if (!$sid) {
    echo '<td class="v fb"><b>Cannot Install | Machine ID Not Found</b><br>ServInfo is for Linux Based Servers Only at this time.</td></tr>'; 
    die();
} else {
    echo '<td class="v">Server Check Passed ... OK!</td></tr>';
}
*/



                    // CHECK WRITE PERMISSION
                    echo '<tr><td class="e">File Write Permission</td><td class="v">';
                    $is_writable = file_put_contents('test.txt', "test");
                    if ($is_writable > 0) {
                        echo "Folder is Writable ... OK!</td></tr>";
                        unlink('test.txt');
                    } else {

                        // GET WEB ROOT FOLDER
                        $www = $_SERVER['DOCUMENT_ROOT'];

                        // DETERMINE WEB USER
                        $user = "Could Not Determine Web User";
                        $user = getenv('APACHE_RUN_USER');
                        if ($user == "") {
                            $user = getenv('USER');
                        }
                        if ($user == "") {
                            $user = get_current_user();
                        }
                        echo "<span class='fb'><b>Cannot Install | Folder is NOT writable</b><br>";
                        echo "The Root of your Web Server: " . $www . "<br>Must be Writable for the Web User: " . $user . "</span>";
                        die();
                    }



                    // CHECK PHP VERSION
                    echo '<tr><td class="e">PHP Version 5.6 Minimum</td><td class="v">';
                    $php_version = phpversion();
                    if ($php_version < 5.6) {
                        die('<font color="firebrick">Cannot Install | PHP v' . $php_version . ' is EOL!<font color="firebrick">Cannot Install | </td></tr></table>');
                    } else {
                        echo 'PHP @ v' . $php_version . ' ... OK!</td></tr>';
                    }



                    echo "</table>";

                ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-default pullup">
                                <div class="panel-heading">
                                    <div class="panel-title">CONFIGURE SETTINGS</div>
                                </div>
                                <div class="panel-body">


                                    <form class="pullup" method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">


                                        <b>Enter URL of Zip File to Download</b><br>
                                        <input type="text" name="zipurl" size="95" value="https://www.classicpress.net/latest.zip"><br><br>

                                        <b>Enter Name of Installer Script to Run</b><br>
                                        <input type="text" name="zipphp" size="95" value="index.php">

                                        <hr>

                                        <input class="btn btn-primary" type="submit" value="Download & Extract" name="submit">
                                    </form>
                                </div>
                            </div>
                        </div>




                    <?php
                    // FORM DATA EXISTS
                } else {

                    // REMOVES TEMP FOLDER
                    function recursiveRemove($dir)
                    {
                        $structure = glob(rtrim($dir, "/") . '/*');
                        if (is_array($structure)) {
                            foreach ($structure as $file) {
                                if (is_dir($file)) recursiveRemove($file);
                                elseif (is_file($file)) unlink($file);
                            }
                        }
                        rmdir($dir);
                    }

                    ?>


                        <div class="row">
                            <div class="col-md-12">
                                <div class="panel panel-primary pullup">
                                    <div class="panel-heading">
                                        <div class="panel-title">EXTRACTING ARCHIVE</div>
                                    </div>
                                    <div class="panel-body">


                                    <?php
                                    $installURL = $_GET['zipurl'];
                                    $installPHP = $_GET['zipphp'];
                                    $downloadZIP = "download.zip";
                                    $installZIP = "package.zip";



                                    // CHECK IF WP CONFIG FILE ALREADY EXISTS
                                    if (file_exists('wp-config.php')) {
                                        echo "CONFIG FILE EXISTS - ALREADY INSTALLED?";
                                        die();
                                    }


                                    // DOWNLOAD AND EXTRACT PACKAGE
                                    $result = fopen($installURL, 'rb');

                                    if (!$result) {
                                        echo "<li class='small'>ALTERNATE DOWNLOAD METHOD</li>";
                                        // IF DOWNLOAD FAILED -> SSL EXCEPTION
                                        $arrContextOptions = array(
                                            "ssl" => array(
                                                "verify_peer" => false,
                                                "verify_peer_name" => false,
                                            ),
                                        );
                                        $result = file_get_contents($installURL, false, stream_context_create($arrContextOptions));
                                    }

                                    if (!$result) {
                                        echo "FILE DOWNLOAD FAILED - ABORT!";
                                        die();
                                    }


                                    file_put_contents($downloadZIP, $result);


                                    $file = dirname(__FILE__) . '/' . $downloadZIP;        // full path to zip file needing extracted
                                    $temp = dirname(__FILE__) . '/zip-temp';        // full path to temp dir to process extractions

                                    $firstDir = null;       // holds the name of the first directory

                                    $zip = new ZipArchive;
                                    $res = $zip->open($file);
                                    if ($res === TRUE) {
                                        $firstDir = $zip->getNameIndex(0);
                                        $zip->extractTo($temp);
                                        $zip->close();
                                        //    $status = "<strong>Success:</strong> '$file' extracted to '$temp'.<br>";
                                        $status = "";
                                        unlink($downloadZIP);
                                    } else {
                                        $status = "<strong>Error:</strong> Could not extract '$file'.<br>";
                                    }
                                    echo $status;


                                    if (empty($firstDir)) {
                                        echo 'Error: first directory was empty!';
                                    } else {
                                        $firstDir = realpath($temp . '/' . $firstDir);
                                        //    echo "First Directory: $firstDir <br>";
                                        if (is_dir($firstDir)) {


                                            // EXTRACT PACKAGE FILES FROM ARCHIVE
                                            $rootPath = realpath($firstDir);

                                            $zip = new ZipArchive();
                                            $zip->open($installZIP, ZipArchive::CREATE | ZipArchive::OVERWRITE);

                                            // Create recursive directory iterator
                                            $files = new RecursiveIteratorIterator(
                                                new RecursiveDirectoryIterator($rootPath),
                                                RecursiveIteratorIterator::LEAVES_ONLY
                                            );

                                            foreach ($files as $name => $file) {
                                                // Skip directories (they are added automatically)
                                                if (!$file->isDir()) {
                                                    // Get real and relative path for current file
                                                    $filePath = $file->getRealPath();
                                                    $relativePath = substr($filePath, strlen($rootPath) + 1);

                                                    // Add current file to archive
                                                    $zip->addFile($filePath, $relativePath);
                                                }
                                            }

                                            $zip->close();
                                        } else {
                                            echo 'Error: Could not find Package Folder';
                                        }
                                    }


                                    echo "<li>Install Package Downloaded...</li>";
                                    $zip = new ZipArchive;
                                    if ($zip->open($installZIP) === TRUE) {
                                        $zip->extractTo('./');
                                        $zip->close();
                                        echo "<li>Package Files Extracted...</li>";
                                        unlink($installZIP);
                                        recursiveRemove($temp);
                                        echo "<li>Install Package Deleted...</li>";
                                    } else {
                                        echo "EXTRACTION FAILED - PACKAGE NOT FOUND";
                                        die();
                                    }


                                    // DELETE EXTRACTOR SCRIPT
                                    unlink('unzip-installer.php');
                                    echo "<li>Zip Extractor Script Deleted...</li>";
                                    echo "<li><strong>Package Extraction Complete</strong>...</li>";


                                    echo '&nbsp;<br>&nbsp;<a class="btn btn-primary button-link bold-text" href="' . $installPHP . '" role="button">Run Installer</a>';


                                    echo '</div></div></div>';
                                }
                                    ?>
                                    </div>
                                </div>
                            </div>
                        </div>